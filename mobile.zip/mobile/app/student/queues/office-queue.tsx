import { useLocalSearchParams, useRouter } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

import AsyncStorage from '@react-native-async-storage/async-storage';

import { API_URL } from '@/constants/backend';
import AppHeader from '../../../components/layout/app-header';
import ServiceItemStep from '../../../components/queue-step/service-item-step';
import QueueTypeStep from '../../../components/queue-step/queue-type-step';
import RequirementStep from '../../../components/queue-step/requirement-step';
import ReviewStep from '../../../components/queue-step/review-step';
import { COLORS } from '../../../constants/theme';

export interface ServiceItem {
  id: number;
  name: string;
  requirements: string[];
}

// ── OFFICE EVENT MODE ───────────────────────────────────────────────
// When ?event_id=NN is present, the student is walking through an
// office event (e.g. "Enrollment") instead of the regular walk-in/
// appointment form. Each step names its own service item(s) + requirement
// checklist and can route to a different office than the one the
// event was launched from.
export interface EventRequirement {
  id: number;
  service_item_id: number;
  requirement: string;
}

export interface EventStepServiceItem {
  service_item_id: number;
  quantity: number;
  name: string;
  requirements: EventRequirement[];
}

export interface EventStep {
  id: number;
  step_order: number;
  title: string;
  description: string | null;
  office_id: number;
  office_name: string;
  office_slug: string;
  service_items: EventStepServiceItem[];
}

export interface EventInfo {
  id: number;
  office_id: number;
  name: string;
  description: string | null;
}

export interface ActiveEventTicket {
  id: number;
  queue_number: string;
  status: string;
  event_step_id: number;
  window_name: string | null;
}

export interface Office {
  id: number;
  name: string;
  slug: string;
  description?: string;
  walkinEnabled: boolean;
  appointmentEnabled: boolean;
  priorityEnabled: boolean;
}

const API_BASE = API_URL;

const STEPS = [
  { label: 'Type' },
  { label: 'Details' },
  { label: 'Requirements' },
  { label: 'Confirm' },
];

function StepIndicator({
  current,
  steps = STEPS,
}: {
  current: number;
  steps?: { label: string }[];
}) {
  const visualIndex = current - 1;

  return (
    <View style={indicator.wrapper}>
      <View style={indicator.row}>
        {steps.map((step, i) => {
          const isDone = i < visualIndex;
          const isActive = i === visualIndex;

          return (
            <View
              key={i}
              style={[
                indicator.stepGroup,
                i < steps.length - 1 && indicator.stepGroupGrow,
              ]}
            >
              <View
                style={[
                  indicator.dot,
                  isDone && indicator.dotDone,
                  isActive && indicator.dotActive,
                  !isDone && !isActive && indicator.dotTodo,
                ]}
              >
                {isDone ? (
                  <Text style={indicator.dotTextDone}>✓</Text>
                ) : (
                  <Text
                    style={[
                      indicator.dotText,
                      isActive && indicator.dotTextActive,
                    ]}
                  >
                    {i + 1}
                  </Text>
                )}
              </View>

              {i < steps.length - 1 && (
                <View
                  style={[indicator.line, isDone && indicator.lineDone]}
                />
              )}
            </View>
          );
        })}
      </View>

      <Text style={indicator.label}>{steps[visualIndex]?.label ?? ''}</Text>
    </View>
  );
}

const indicator = StyleSheet.create({
  wrapper: {
    marginBottom: 16,
  },

  row: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    marginBottom: 6,
  },

  stepGroup: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  stepGroupGrow: {
    flex: 1,
  },

  dot: {
    width: 26,
    height: 26,
    borderRadius: 13,
    justifyContent: 'center',
    alignItems: 'center',
  },

  dotDone: {
    backgroundColor: '#22C55E',
  },

  dotActive: {
    backgroundColor: COLORS.primary,
    borderWidth: 2,
    borderColor: '#f5c5c8',
  },

  dotTodo: {
    backgroundColor: '#fff',
    borderWidth: 1.5,
    borderColor: '#ddd',
  },

  dotText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#bbb',
  },

  dotTextActive: {
    color: '#fff',
  },

  dotTextDone: {
    fontSize: 11,
    fontWeight: '700',
    color: '#fff',
  },

  line: {
    flex: 1,
    minWidth: 20,
    height: 2,
    backgroundColor: '#ddd',
    marginHorizontal: 6,
  },

  lineDone: {
    backgroundColor: '#22C55E',
  },

  label: {
    textAlign: 'center',
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.primary,
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
});

export default function OfficeQueue() {
  const router = useRouter();


  const { office: officeSlug, event_id: eventIdParam } =
    useLocalSearchParams<{ office?: string; event_id?: string }>();

  const eventId = eventIdParam ? parseInt(eventIdParam, 10) : 0;
  const isEventMode = !!eventId;

  const [office, setOffice] = useState<Office | null>(null);
  const [loadingOffice, setLoadingOffice] = useState(true);

  // Event-mode state
  const [loadingEvent, setLoadingEvent] = useState(isEventMode);
  const [eventInfo, setEventInfo] = useState<EventInfo | null>(null);
  const [eventSteps, setEventSteps] = useState<EventStep[]>([]);
  const [currentStep, setCurrentStep] = useState<EventStep | null>(null);
  const [currentStepIndex, setCurrentStepIndex] = useState<number | null>(null);
  // Which step is being displayed — usually equal to currentStepIndex, but
  // moves independently when the student browses Back to a prior step.
  const [viewIndex, setViewIndex] = useState<number | null>(null);
  const [eventCompleted, setEventCompleted] = useState(false);
  const [eventActiveTicket, setEventActiveTicket] = useState<ActiveEventTicket | null>(null);
  const [checkedEventReqIds, setCheckedEventReqIds] = useState<number[]>([]);

  // Mirrors of currentStepIndex/viewIndex for the silent background poll
  // below, so it always reads the latest values instead of a stale
  // closure captured when the interval was set up.
  const currentStepIndexRef = useRef<number | null>(null);
  const viewIndexRef = useRef<number | null>(null);
  useEffect(() => {
    currentStepIndexRef.current = currentStepIndex;
  }, [currentStepIndex]);
  useEffect(() => {
    viewIndexRef.current = viewIndex;
  }, [viewIndex]);

  const [step, setStep] = useState(1);
  const [studentId, setStudentId] = useState(0);

  const [queueType, setQueueType] =
    useState<'walkin' | 'appointment'>('walkin');

  const [appointmentSlipConfirmed, setAppointmentSlipConfirmed] =
    useState(false);

  const [serviceItems, setServiceItems] = useState<ServiceItem[]>([]);
  const [selectedServiceItems, setSelectedServiceItems] = useState<number[]>([]);
  const [checkedRequirements, setCheckedRequirements] = useState<string[]>([]);
  const [quantities, setQuantities] = useState<Record<number, number>>({});

  const [priority, setPriority] = useState(false);
  const [priorityReason, setPriorityReason] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  const [queueNumber, setQueueNumber] = useState('');
  const [assignedWindow, setAssignedWindow] = useState('');

  useEffect(() => {
    if (!officeSlug) {
      // No office selected — bounce back to the dashboard.
      Alert.alert('Error', 'No office selected.');
      router.replace('/student/home');
      return;
    }

    loadUser();
    fetchOffice(officeSlug);
  }, [officeSlug]);

  useEffect(() => {
    if (!office) return;
    fetchServiceItems(office.id);
  }, [office]);

  useEffect(() => {
    if (!isEventMode || !office || !studentId) return;
    fetchEventDetail();
  }, [isEventMode, office, studentId]);

  // Poll in the background while the student has an active ticket for
  // the current step, so the moment that ticket is served/completed and
  // the backend advances to the next step, this screen picks it up on
  // its own — no manual reload needed.
  useEffect(() => {
    if (!isEventMode || !office || !studentId) return;
    const ticketMatchesCurrentStep =
      !!eventActiveTicket && eventActiveTicket.event_step_id === currentStep?.id;
    if (!ticketMatchesCurrentStep || eventCompleted) return;

    const interval = setInterval(() => {
      fetchEventDetail({ silent: true });
    }, 4000);

    return () => clearInterval(interval);
  }, [isEventMode, office, studentId, eventActiveTicket, currentStep, eventCompleted]);

  const loadUser = async () => {
    const user = await AsyncStorage.getItem('user');
    if (user) {
      const parsed = JSON.parse(user);
      setStudentId(parsed.id);
    }
  };

  const fetchOffice = async (slug: string) => {
    try {
      const response = await fetch(
        `${API_BASE}/queue_process.php?slug=${encodeURIComponent(slug)}`
      );
      const data = await response.json();

      if (!data.success || !data.office) {
        Alert.alert('Error', 'That office is not available.');
        router.replace('/student/home');
        return;
      }

      // Fall back to enabled if the office has no config row yet.
      const o = data.office;
      setOffice({
        id: o.id,
        name: o.name,
        slug: o.slug,
        description: o.description,
        walkinEnabled: o.walkin_enabled === null ? true : !!o.walkin_enabled,
        appointmentEnabled:
          o.appointment_enabled === null ? true : !!o.appointment_enabled,
        priorityEnabled:
          o.priority_enabled === null ? true : !!o.priority_enabled,
      });

      // Default queue type to whichever option this office actually
      // supports.
      if (o.walkin_enabled === false && o.appointment_enabled !== false) {
        setQueueType('appointment');
      } else {
        setQueueType('walkin');
      }
    } catch (error) {
      console.log(error);
      Alert.alert('Error', 'Unable to load this office right now.');
      router.replace('/student/home');
    } finally {
      setLoadingOffice(false);
    }
  };

  // SERVICE ITEMS — scoped to this office only, and used by both queue types.
  const fetchServiceItems = async (officeId: number) => {
    try {
      const response = await fetch(
        `${API_BASE}/get_service_items.php?office_id=${officeId}`
      );
      const data = await response.json();
      if (data.success) {
        setServiceItems(data.service_items);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const fetchEventDetail = async (opts: { silent?: boolean } = {}) => {
    if (!office) return;
    const silent = !!opts.silent;

    try {
      if (!silent) setLoadingEvent(true);

      const response = await fetch(
        `${API_BASE}/office-queue.php?action=event&event_id=${eventId}&office_id=${office.id}&student_id=${studentId}`
      );
      const data = await response.json();

      if (!data.success) {
        if (!silent) {
          Alert.alert('Error', data.message || 'This event is not available.');
          router.replace('/student/home');
        }
        return;
      }

      const prevCurrentStepIndex = currentStepIndexRef.current;
      const prevViewIndex = viewIndexRef.current;
      const nextCurrentStepIndex = data.current_step_index;
      const stepAdvanced = prevCurrentStepIndex !== nextCurrentStepIndex;

      setEventInfo(data.event);
      setEventSteps(data.steps || []);
      setCurrentStep(data.current_step);
      setCurrentStepIndex(nextCurrentStepIndex);
      setEventCompleted(!!data.event_completed);
      setEventActiveTicket(data.active_ticket);

      // Auto-follow the student's view forward when their current-step
      // ticket completes and the event moves on. If they'd browsed away
      // to another step, leave their view alone — don't yank them back.
      const wasViewingCurrent =
        prevViewIndex === null ||
        prevCurrentStepIndex === null ||
        prevViewIndex === prevCurrentStepIndex;

      if (!silent || wasViewingCurrent) {
        setViewIndex(nextCurrentStepIndex);
      }

      if (!silent || stepAdvanced) {
        setCheckedEventReqIds([]);
      }
    } catch (error) {
      console.log(error);
      if (!silent) {
        Alert.alert('Error', 'Unable to load this event right now.');
        router.replace('/student/home');
      }
    } finally {
      if (!silent) setLoadingEvent(false);
    }
  };

  const toggleEventRequirement = (id: number) => {
    setCheckedEventReqIds((prev) =>
      prev.includes(id) ? prev.filter((r) => r !== id) : [...prev, id]
    );
  };

  // The step currently being displayed — may be an earlier step the
  // student is browsing back to, not necessarily the one they can submit.
  const viewStep = viewIndex !== null ? eventSteps[viewIndex] ?? currentStep : currentStep;
  const isViewingCurrentStep =
    viewIndex === null || currentStepIndex === null || viewIndex === currentStepIndex;

  // True when browsing a step that hasn't been reached yet — separate
  // from browsing back to an earlier, already-passed step — so the UI
  // can explain why joining is locked instead of just hiding the button.
  const isFutureStep =
    viewIndex !== null && currentStepIndex !== null && viewIndex > currentStepIndex;

  // Whether the Back button should render — purely a function of position
  // in the list, independent of join/ticket state, so it always works
  // whenever there's somewhere to go back to.
  const canGoBackEventStep = viewIndex !== null && viewIndex > 0;

  // Whether there's a next step to browse forward into — the last step
  // in the sequence has nowhere further to go, so the Next button
  // shouldn't render there.
  const canGoNextEventStep =
    viewIndex !== null && !!eventSteps[viewIndex + 1];

  // The Join button only makes sense on the current step. If a ticket's
  // already been submitted for it, it stays as the Join button — shown
  // disabled — instead of turning into Next when there's nowhere further
  // to go (i.e. this is the last step in the sequence).
  //
  // Guard: only treat eventActiveTicket as blocking THIS step if it's
  // actually tied to it (event_step_id matches). Otherwise a leftover
  // ticket from an earlier, already-finished step would incorrectly make
  // the current step look already-queued (checkboxes pre-checked, Join
  // disabled) before the student has done anything here.
  const isActiveTicketForCurrentStep =
    !!eventActiveTicket && eventActiveTicket.event_step_id === currentStep?.id;

  const showJoinEventButton =
    isViewingCurrentStep && (!isActiveTicketForCurrentStep || !canGoNextEventStep);
  const showNextEventButton = !showJoinEventButton && canGoNextEventStep;

  // Requirements can only be ticked/unticked on the current step, and
  // only before a ticket has been submitted for it.
  const canEditEventRequirements = isViewingCurrentStep && !isActiveTicketForCurrentStep;

  // A step counts as "done" (requirements shown pre-checked + locked)
  // once its ticket is queued (current step) or it's already behind us
  // (a past step). A future step is neither done nor editable yet.
  const isDoneEventStep =
    (!isViewingCurrentStep && !isFutureStep) ||
    (isViewingCurrentStep && isActiveTicketForCurrentStep);

  // Step back to the previous step in this event's sequence (view-only —
  // does not undo an already-submitted ticket for that step).
  const goToPreviousEventStep = () => {
    if (viewIndex === null || viewIndex <= 0) return;
    const prevIndex = viewIndex - 1;
    if (!eventSteps[prevIndex]) return;

    setViewIndex(prevIndex);
    setCheckedEventReqIds([]);
  };

  // Step forward through the sequence — the student can browse ahead
  // to preview later steps, but can only ever join the queue while
  // viewIndex === currentStepIndex (see canJoinEventQueue below).
  const goToNextEventStep = () => {
    if (viewIndex === null) return;
    const nextIndex = viewIndex + 1;
    if (!eventSteps[nextIndex]) return;

    setViewIndex(nextIndex);
    setCheckedEventReqIds([]);
  };

  // Every requirement across every service item this step needs — the
  // student must check all of them before joining, mirrored server-
  // side in office-queue.php since this guard can be bypassed.
  const stepRequirementIds = (viewStep?.service_items ?? []).flatMap((item) =>
    (item.requirements ?? []).map((r) => r.id)
  );
  const allEventRequirementsChecked =
    stepRequirementIds.length === 0 ||
    stepRequirementIds.every((id) => checkedEventReqIds.includes(id));

  // Gate the Join Queue button until requirements are checked and,
  // if priority is toggled on, a reason has been entered. Also blocked
  // while the student already has an active ticket for this step.
  const canJoinEventQueue =
    isViewingCurrentStep &&
    !isActiveTicketForCurrentStep &&
    allEventRequirementsChecked &&
    (!priority || priorityReason.trim().length > 0) &&
    !submitting;

  const joinEventQueue = async () => {
    if (!currentStep) return;

    if (isActiveTicketForCurrentStep) {
      Alert.alert('Error', 'You already have an active queue for this step.');
      return;
    }

    if (office?.priorityEnabled && priority && !priorityReason.trim()) {
      Alert.alert('Error', 'Please enter a reason for priority lane.');
      return;
    }

    if (!allEventRequirementsChecked) {
      Alert.alert('Error', 'Please confirm all requirements are met before joining the queue.');
      return;
    }

    try {
      setSubmitting(true);

      const response = await fetch(`${API_BASE}/office-queue.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'event',
          student_id: studentId,
          event_id: eventId,
          event_step_id: currentStep.id,
          priority: office?.priorityEnabled ? priority : false,
          priority_reason: office?.priorityEnabled ? priorityReason : '',
          req_check: checkedEventReqIds,
        }),
      });

      const data = await response.json();

      if (data.success) {
        setQueueNumber(data.queue_number || '');
        setAssignedWindow(data.window_name || 'Not Assigned');

        // Refresh immediately so eventActiveTicket/currentStep reflect
        // the ticket we just created right away — otherwise the Join
        // button and banner would keep showing the pre-join state
        // until the next 8s poll (or a manual reload) picks it up.
        await fetchEventDetail({ silent: true });
        setPriority(false);
        setPriorityReason('');

        setShowSuccessModal(true);
      } else {
        Alert.alert('Error', data.message);
      }
    } catch (error) {
      Alert.alert('Error', 'Unable to join queue');
    } finally {
      setSubmitting(false);
    }
  };

  const resetForm = () => {
    setStep(1);
    setQueueType('walkin');
    setAppointmentSlipConfirmed(false);
    setSelectedServiceItems([]);
    setCheckedRequirements([]);
    setQuantities({});
    setPriority(false);
    setPriorityReason('');
    setQueueNumber('');
    setAssignedWindow('');
  };

  const joinQueue = async () => {
    if (!office) return;

    if (queueType === 'walkin' && !office.walkinEnabled) {
      Alert.alert('Error', 'Walk-in queueing is not available for this office.');
      return;
    }

    if (queueType === 'appointment' && !office.appointmentEnabled) {
      Alert.alert('Error', 'Appointments are not available for this office.');
      return;
    }

    if (!selectedServiceItems.length) {
      Alert.alert('Error', 'Please select at least one service item or service.');
      return;
    }

    if (queueType === 'appointment' && !appointmentSlipConfirmed) {
      Alert.alert('Error', 'Please confirm you have your Appointment Slip.');
      return;
    }

    if (office.priorityEnabled && priority && !priorityReason.trim()) {
      Alert.alert('Error', 'Please enter a reason for priority lane.');
      return;
    }

    try {
      setSubmitting(true);

      const items = selectedServiceItems.map((id) => ({
        service_item_id: id,
        quantity: quantities[id] || 1,
      }));

      const response = await fetch(`${API_BASE}/office-queue.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          student_id: studentId,
          office_id: office.id,
          type: queueType,
          appointment_slip_confirmed:
            queueType === 'appointment' ? appointmentSlipConfirmed : false,
          priority: office.priorityEnabled ? priority : false,
          priority_reason: office.priorityEnabled ? priorityReason : '',
          service_items: items,
        }),
      });

      const data = await response.json();

      if (data.success) {

        setQueueNumber(data.queue_number || '');
        setAssignedWindow(data.window_name || 'Not Assigned');
        setShowSuccessModal(true);
      } else {
        Alert.alert('Error', data.message);
      }
    } catch (error) {
      Alert.alert('Error', 'Unable to join queue');
    } finally {
      setSubmitting(false);
    }
  };

  const goBack = () => {
    if (step === 1) return;
    setStep(step - 1);
  };

  if (loadingOffice || !office) {
    return (
      <View style={styles.container}>
        <AppHeader />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <AppHeader title={isEventMode ? (eventInfo?.name ?? 'Event Queue') : `${office.name} Queue`} />

      <ScrollView contentContainerStyle={styles.content}>
        {isEventMode ? (
          loadingEvent ? (
            <View style={styles.eventLoadingBox}>
              <ActivityIndicator size="large" color={COLORS.primary} />
            </View>
          ) : eventCompleted ? (
            <View style={styles.eventCard}>
              <Text style={styles.eventCardStepTitle}>All steps completed 🎉</Text>
              <Text style={styles.eventCardDescription}>
                You've finished every step of {eventInfo?.name}.
              </Text>
              <TouchableOpacity
                style={styles.modalButton}
                onPress={() => router.replace('/student/home')}
              >
                <Text style={styles.modalButtonText}>Back to Dashboard</Text>
              </TouchableOpacity>
            </View>
          ) : currentStep ? (
            <View style={styles.eventCard}>
              <Text style={styles.eventCardName}>{eventInfo?.name}</Text>
              {!!eventInfo?.description && (
                <Text style={styles.eventCardDescription}>{eventInfo.description}</Text>
              )}

              {isViewingCurrentStep && isActiveTicketForCurrentStep && (
                <View style={styles.eventStepBadge}>
                  <Text style={styles.eventStepBadgeText}>Current Step Ongoing</Text>
                </View>
              )}

              {isFutureStep && (
                <View style={styles.eventStepBadge}>
                  <Text style={styles.eventStepBadgeText}>Complete the Current Queue</Text>
                </View>
              )}

              {!isViewingCurrentStep && !isFutureStep && (
                <View style={styles.eventStepBadgeFinished}>
                  <Text style={styles.eventStepBadgeTextFinished}>Finished Queue</Text>
                </View>
              )}

              <StepIndicator
                current={(viewIndex ?? currentStepIndex ?? 0) + 1}
                steps={eventSteps.map((s) => ({ label: s.title }))}
              />

              <Text style={styles.eventCardStepTitle}>{viewStep?.title}</Text>
              {!!viewStep?.description && (
                <Text style={styles.eventCardDescription}>{viewStep.description}</Text>
              )}
              <Text style={styles.eventCardOffice}>at {viewStep?.office_name}</Text>

              {!isViewingCurrentStep && !isFutureStep && (
                <Text style={styles.eventDocNoReq}>
                  Viewing a previous step. Tap Next to return to your current step.
                </Text>
              )}

              {!!viewStep && viewStep.service_items.length > 0 && (
                <View style={styles.eventDocsBox}>
                  <Text style={styles.eventDocsLabel}>Please confirm you have these ready</Text>

                  {viewStep.service_items.map((item) => (
                    <View key={item.service_item_id} style={styles.eventDocGroup}>
                      <Text style={styles.eventDocName}>
                        {item.name}
                        {item.quantity > 1 ? ` (x${item.quantity})` : ''}
                      </Text>

                      {(item.requirements ?? []).length === 0 ? (
                        <Text style={styles.eventDocNoReq}>No additional requirements.</Text>
                      ) : (
                        item.requirements.map((req) => {
                          const checked = canEditEventRequirements
                            ? checkedEventReqIds.includes(req.id)
                            : isDoneEventStep;
                          return (
                            <TouchableOpacity
                              key={req.id}
                              style={styles.eventReqRow}
                              activeOpacity={canEditEventRequirements ? 0.7 : 1}
                              disabled={!canEditEventRequirements}
                              onPress={() => toggleEventRequirement(req.id)}
                            >
                              <View
                                style={[
                                  styles.eventCheckbox,
                                  checked && styles.eventCheckboxChecked,
                                  !canEditEventRequirements && styles.eventCheckboxDisabled,
                                ]}
                              >
                                {checked && <Text style={styles.eventCheckMark}>✓</Text>}
                              </View>
                              <Text style={styles.eventReqText}>{req.requirement}</Text>
                            </TouchableOpacity>
                          );
                        })
                      )}
                    </View>
                  ))}
                </View>
              )}

              {isViewingCurrentStep && office.priorityEnabled && (
                <View style={styles.eventPriorityBox}>
                  <TouchableOpacity
                    style={styles.eventReqRow}
                    activeOpacity={0.7}
                    onPress={() => setPriority(!priority)}
                  >
                    <View
                      style={[styles.eventCheckbox, priority && styles.eventCheckboxChecked]}
                    >
                      {priority && <Text style={styles.eventCheckMark}>✓</Text>}
                    </View>
                    <Text style={styles.eventReqText}>
                      Priority Lane (PWD, pregnant, or senior citizen)
                    </Text>
                  </TouchableOpacity>

                  {priority && (
                    <TextInput
                      style={styles.eventPriorityInput}
                      placeholder="Reason for priority"
                      placeholderTextColor={COLORS.gray}
                      value={priorityReason}
                      onChangeText={setPriorityReason}
                    />
                  )}
                </View>
              )}

              <View style={styles.eventStepActions}>
                {showJoinEventButton ? (
                  <TouchableOpacity
                    style={[styles.eventNextButton, !canJoinEventQueue && styles.eventSubmitButtonDisabled]}
                    disabled={!canJoinEventQueue}
                    onPress={joinEventQueue}
                  >
                    <Text style={styles.modalButtonText}>
                      {submitting ? 'Joining…' : 'Confirm & Join Queue'}
                    </Text>
                  </TouchableOpacity>
                ) : (
                  showNextEventButton && (
                    <TouchableOpacity
                      style={styles.eventNextButton}
                      onPress={goToNextEventStep}
                    >
                      <Text style={styles.modalButtonText}>Next</Text>
                    </TouchableOpacity>
                  )
                )}
                {canGoBackEventStep && (
                  <TouchableOpacity
                    style={styles.eventBackButton}
                    onPress={goToPreviousEventStep}
                  >
                    <Text style={styles.eventBackButtonText}>Back</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          ) : (
            <View style={styles.eventCard}>
              <Text style={styles.eventCardStepTitle}>No steps configured for this event.</Text>
              <TouchableOpacity
                style={styles.modalButton}
                onPress={() => router.replace('/student/home')}
              >
                <Text style={styles.modalButtonText}>Back to Dashboard</Text>
              </TouchableOpacity>
            </View>
          )
        ) : (
        <>
        <StepIndicator current={step} />

        {step === 1 && (
          <QueueTypeStep
            queueType={queueType}
            setQueueType={setQueueType}
            walkinEnabled={office.walkinEnabled}
            appointmentEnabled={office.appointmentEnabled}
            onNext={() => setStep(2)}
          />
        )}

        {step === 2 && (
          <ServiceItemStep
            service_items={serviceItems}
            selectedServiceItems={selectedServiceItems}
            setSelectedServiceItems={setSelectedServiceItems}
            quantities={quantities}
            setQuantities={setQuantities}
            priority={priority}
            setPriority={setPriority}
            priorityReason={priorityReason}
            setPriorityReason={setPriorityReason}
            priorityEnabled={office.priorityEnabled}
            onNext={() => setStep(3)}
            onBack={goBack}
          />
        )}

        {step === 3 && (
          <RequirementStep
            service_items={serviceItems}
            selectedServiceItems={selectedServiceItems}
            checkedRequirements={checkedRequirements}
            setCheckedRequirements={setCheckedRequirements}
            queueType={queueType}
            appointmentSlipConfirmed={appointmentSlipConfirmed}
            setAppointmentSlipConfirmed={setAppointmentSlipConfirmed}
            onNext={() => setStep(4)}
            onBack={goBack}
          />
        )}

        {step === 4 && (
          <ReviewStep
            queueType={queueType}
            appointmentSlipConfirmed={appointmentSlipConfirmed}
            service_items={serviceItems}
            selectedServiceItems={selectedServiceItems}
            quantities={quantities}
            priority={priority}
            priorityReason={priorityReason}
            onSubmit={joinQueue}
            onBack={goBack}
            submitting={submitting}
          />
        )}
        </>
        )}
      </ScrollView>

      <Modal visible={showSuccessModal} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>
              {isEventMode ? "Step joined!" : "You're in the queue!"}
            </Text>

            {!!queueNumber && (
              <Text style={styles.queueNumberText}>{queueNumber}</Text>
            )}

            <Text style={styles.modalLabel}>Assigned Counter</Text>
            <Text style={styles.windowText}>{assignedWindow}</Text>

            <Text style={styles.modalSubtitle}>
              {isEventMode
                ? `Your request for "${currentStep?.title ?? 'this step'}" has been submitted to ${currentStep?.office_name ?? eventInfo?.name}.`
                : `Your request has been submitted to ${office.name}.`}
            </Text>

            <TouchableOpacity
              style={styles.modalButton}
              onPress={() => {
                setShowSuccessModal(false);
                resetForm();
                router.replace('/student/home');
              }}
            >
              <Text style={styles.modalButtonText}>OK</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },

  content: {
    padding: 20,
    paddingBottom: 50,
  },

  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },

  modalCard: {
    width: '85%',
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 30,
    alignItems: 'center',
  },

  modalTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: COLORS.primary,
    marginBottom: 10,
    textAlign: 'center',
  },

  queueNumberText: {
    fontSize: 40,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: 12,
  },

  modalLabel: {
    fontSize: 13,
    color: COLORS.gray,
  },

  windowText: {
    fontSize: 20,
    fontWeight: '700',
    color: COLORS.secondary,
    marginTop: 4,
    marginBottom: 14,
  },

  modalSubtitle: {
    fontSize: 14,
    color: COLORS.gray,
    textAlign: 'center',
    marginBottom: 10,
  },

  modalButton: {
    marginTop: 10,
    backgroundColor: COLORS.primary,
    paddingHorizontal: 40,
    paddingVertical: 14,
    borderRadius: 12,
  },

  modalButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },

  // ── Event mode ──
  eventLoadingBox: {
    paddingVertical: 60,
    alignItems: 'center',
  },

  eventCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
  },

  eventActiveTicketBanner: {
    backgroundColor: '#F8F8F8',
    borderRadius: 14,
    padding: 14,
    marginTop: 12,
    marginBottom: 4,
    alignItems: 'center',
  },

  eventActiveTicketLabel: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.secondary,
    marginBottom: 6,
    textAlign: 'center',
  },

  eventCardName: {
    fontSize: 20,
    fontWeight: '800',
    color: COLORS.primary,
    marginBottom: 4,
  },

  eventCardDescription: {
    fontSize: 13,
    color: COLORS.gray,
    marginBottom: 10,
    lineHeight: 19,
  },

  eventStepBadge: {
    alignSelf: 'center',
    backgroundColor: COLORS.primarySoft,
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 5,
    marginBottom: 10,
  },

  eventStepBadgeFinished: {
    alignSelf: 'center',
    backgroundColor: '#DCFCE7',
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 5,
    marginBottom: 10,
  },

  eventStepBadgeTextFinished: {
    fontSize: 11,
    fontWeight: '700',
    color: '#22C55E',
    letterSpacing: 0.4,
    textTransform: 'uppercase',
  },

  eventStepBadgeText: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.primary,
    letterSpacing: 0.4,
    textTransform: 'uppercase',
  },

  eventCardStepTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.secondary,
    marginBottom: 2,
  },

  eventCardOffice: {
    fontSize: 13,
    fontWeight: '600',
    color: COLORS.gray,
    marginBottom: 16,
  },

  eventDocsBox: {
    marginBottom: 16,
  },

  eventDocsLabel: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.secondary,
    marginBottom: 10,
  },

  eventDocGroup: {
    marginBottom: 14,
  },

  eventDocName: {
    fontSize: 14,
    fontWeight: '700',
    color: COLORS.primary,
    marginBottom: 6,
  },

  eventDocNoReq: {
    fontSize: 12,
    color: COLORS.gray,
    fontStyle: 'italic',
  },

  eventReqRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 7,
  },

  eventCheckbox: {
    width: 20,
    height: 20,
    borderRadius: 5,
    borderWidth: 1.5,
    borderColor: '#ddd',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },

  eventCheckboxChecked: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },

  eventCheckboxDisabled: {
    opacity: 0.6,
  },

  eventCheckMark: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '700',
  },

  eventReqText: {
    flex: 1,
    fontSize: 13,
    fontWeight: '600',
    color: COLORS.secondary,
  },

  eventPriorityBox: {
    backgroundColor: '#F8F8F8',
    borderRadius: 14,
    padding: 12,
    marginBottom: 20,
  },

  eventPriorityInput: {
    marginTop: 8,
    backgroundColor: '#fff',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#E5E5E5',
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 13,
    color: COLORS.secondary,
  },

  eventSubmitButton: {
    backgroundColor: COLORS.primary,
    paddingVertical: 15,
    borderRadius: 12,
    alignItems: 'center',
  },

  eventSubmitButtonDisabled: {
    opacity: 0.6,
  },

  eventStepActions: {
    flexDirection: 'column',
    gap: 12,
    marginTop: 8,
  },

  eventBackButton: {
    borderWidth: 1.5,
    borderColor: COLORS.border,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },

  eventBackButtonText: {
    color: COLORS.secondary,
    fontSize: 15,
    fontWeight: '700',
  },

  eventNextButton: {
    backgroundColor: COLORS.primary,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },

  eventReviewCard: {
    backgroundColor: '#F8F8F8',
    borderRadius: 14,
    padding: 12,
    marginTop: 14,
    marginBottom: 8,
  },

  eventReviewRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 9,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },

  modalRowLast: {
    borderBottomWidth: 0,
  },

  eventReviewValue: {
    flex: 1,
    textAlign: 'right',
    color: COLORS.secondary,
    fontWeight: '700',
    fontSize: 13,
  },
});